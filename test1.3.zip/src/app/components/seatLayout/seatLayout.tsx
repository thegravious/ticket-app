import Seatinner from "../seatinnerlayout/seatinner"

const SeatLayout = () => {
  return (
    <div>
      <Seatinner/>
    </div>
  );
};

export default SeatLayout;