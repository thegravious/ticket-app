import SeatLayout from "../components/seatLayout/seatLayout"


export default function Home() {
  return(
    <div>
      <SeatLayout/>
    </div>
  )
}
